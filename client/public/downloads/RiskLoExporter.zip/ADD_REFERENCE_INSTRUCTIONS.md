# How to Add Newtonsoft.Json Reference in NinjaTrader 8

## Quick Fix for Compilation Errors

If you're getting errors about `Newtonsoft.Json` not being found, you need to add a reference to the DLL in NinjaTrader.

### Method 1: Add Reference in NinjaScript Editor (Recommended)

1. **Open NinjaScript Editor**: Tools → NinjaScript Editor (or press F3)

2. **Right-click on "References"** in the left panel (under your project)

3. **Select "Add Reference..."**

4. **Click "Browse"** button

5. **Navigate to**: `Documents\NinjaTrader 8\bin\Custom\`

6. **Select**: `Newtonsoft.Json.dll`

7. **Click "OK"**

8. **Compile again**: Click the "Compile" button

### Method 2: Copy DLL to Bin Folder

If Method 1 doesn't work:

1. **Copy** `Newtonsoft.Json.dll` from: `Documents\NinjaTrader 8\bin\Custom\`

2. **Paste** it into: `Documents\NinjaTrader 8\bin\`

3. **Restart NinjaTrader**

4. **Compile again**

### Method 3: Use NuGet Package Manager

1. **Tools → Options → AddOns**

2. **Right-click** on the AddOns list

3. **Select "Manage NuGet Packages"**

4. **Search** for "Newtonsoft.Json"

5. **Install** version 13.0.1 or later

6. **Compile again**

## After Adding Reference

Once the reference is added, the compilation errors should be resolved. The code has been fixed to:
- Remove `.Value` calls on `double` types (lines 439, 447)
- Remove `Formatting.Indented` parameter (line 614)

Try compiling again after adding the reference!

